﻿namespace WebApplication1.Controllers
{
    internal class SwaggerIntegrationContext
    {
        public SwaggerIntegrationContext()
        {
        }
    }
}