import React, { Component } from 'react';
import NavBar from './navBar'
import Counters from './counters'
import './App.css';
import axios from 'axios';
import Swal from 'sweetalert2'

const  apiUrl =  "http://localhost:50976/api/"
class AppOrder extends Component{
    
    state = {
    counters: [],   

  }
  
  componentDidMount() {
    axios.get(apiUrl + 'GetAllRecords')
      .then(res => {     
       this.setState({counters: res.data}); 
      })
  }


   
  handleIncrement = counter =>{
    
   const counters = [...this.state.counters];
   const index = counters.indexOf(counter);

   counters[index]={...counter}
   counters[index].order++;
   this.setState({counters});
  
  };

  handleDecrement = counter =>{
    const counters = [...this.state.counters];
    const index = counters.indexOf(counter);
    counters[index]={...counter}
    if (counters[index].order > 0) {
      counters[index].order--;
    }
  
    this.setState({counters});
   
   };
  
  handleReset = () => {
    const counters = this.state.counters.map( c => {
        c.order = 0;
        return c;
    });
    this.setState({counters});
   
  };

  handleCheckout = (counters) => { 
    let totalAmt = this.handleSumAmount();
    Swal.fire(`Total amount order ${ this.currencyFormat(totalAmt)}`);
    this.FilterItemOrder(this.state.counters);
    
  };

  FilterItemOrder(){
    const filtered = this.state.counters.filter(c=>c.order > 0)      
    alert(JSON.stringify(filtered)); 
  }

  currencyFormat(num) {
    if (num === null) {
       num = 0.00; 
    }
    return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
 }

  handleDelete = (counterId)=>{
    const counters = this.state.counters.filter(c => c.id !== counterId);
    this.setState({counters});
  };

  handleSumAmount = (counters) => {
    const filtered = this.state.counters.filter(c=>c.order > 0)  
    var totalAmt = 0;
    filtered.forEach(d => totalAmt += d.order * d.UnitPrice)
    return totalAmt;
  };

  render(){
    return(
      <React.Fragment>
        <NavBar 
        totalCounters={this.state.counters.filter(c=>c.order > 0).length}  
        />             
        <main className="container">   
          <Counters
          counters={this.state.counters}
          onReset={this.handleReset}
          onIncrement={this.handleIncrement}
          onDecrement={this.handleDecrement}
          onDelete={this.handleDelete}
          onCheckout={this.handleCheckout}    
           />           
        </main>
      </React.Fragment>
    )
  }
}
export default  AppOrder;
