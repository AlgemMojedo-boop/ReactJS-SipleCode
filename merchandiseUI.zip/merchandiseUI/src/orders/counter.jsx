import React, { Component } from 'react';  
//import Swal from 'sweetalert2'
const PhotoUrl = "http://localhost:50976/Photos/";
class Counter extends Component {
    render() {   
        const PhotoFile = PhotoUrl +  this.props.counter.PhotoFileName ;     
        return (  
            <div>  
               
               <img src={PhotoFile} height="100" width="100" alt=""></img>       
                <span className={this.getBadgeClasses()}>{this.formatCount()}</span>  
                <button 
                    onClick= {() => this.props.onDecrement(this.props.counter)}
                    className="btn btn-secondary btn-sm m-2"
                    > -
                 </button>
                <button 
                    onClick= {() => this.props.onIncrement(this.props.counter)}
                    className="btn btn-secondary btn-sm  m-2"
                    > +
                </button>  
                
                <button onClick={() => this.props.onDelete(                                                    
                    this.props.counter.id
                    )}
                    className="btn btn-danger btn-sm m-2">Exclude
                 </button>    
                 <span>{this.props.counter.ItemName} </span>  
               
                 <span>{this.currencyFormat(this.props.counter.UnitPrice)}/</span>
                 <span>{this.props.counter.UnitMeasurement}</span>  
            </div>       
        );
    }
    
    currencyFormat(num) {
        if (num === null) {
           num = 0.00; 
        }
        return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
     }

    getBadgeClasses(){
        let classes ="badge m-2 badge-";
        if (this.props.counter.order === null) {
            this.props.counter.order = 0;
        }
        classes += this.props.counter.order === 0 ? "warning":"primary";
        return classes;
    }

    formatCount(){
        if (this.props.counter === null) {
            this.props.counter = 0;
        }
        const {order} = this.props.counter;
        return order === 0 ? "Zero" : order;
    }
}
 
export default Counter;