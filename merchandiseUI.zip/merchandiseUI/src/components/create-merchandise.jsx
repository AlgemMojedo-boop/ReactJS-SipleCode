import React, { Component } from 'react'
import Swal from 'sweetalert2';
import axios from 'axios';
const  apiUrl =  "http://localhost:50976/api/"
class CreateMerchandise extends Component {
    constructor (props){
        super(props);
        this.onSubmit = this.onSubmit.bind(this);       
        this.state={
            ItemName:'' ,
            UnitMeasurement:'',
            UnitPrice: '',
            Priority: '',
            Completed:false,
            PhotoFileName: '',         
       }     
    }

    onSubmit(e){        
        e.preventDefault();
        
        if (this.state.ItemName === '') {
         Swal.fire({
             icon: 'error',
             title: 'Oops...',
              text: 'Item Name is required!',
          })  
          return;
        }
        if (this.state.UnitMeasurement === '') {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                 text: 'Unit measurement is required!',
            })  
             return;
        }
        if ( this.state.UnitPrice === '' ||this.state.UnitPrice === 0) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                 text: 'Unit price is required!',
            })  
             return;
        }
      
        if (this.state.PhotoFileName === '') {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                 text: 'Select item image!',
            })  
             return;
        }
        if (this.state.Priority === '') {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                 text: 'Select item priority!',
            })  
             return;
        }
       // creates entity
       //"x-rapidapi-host": "fairestdb.p.rapidapi.com",
       //"x-rapidapi-key": "apikey",
        fetch(apiUrl + "AddRecord", {
            "method": "POST",
            "headers": {
            "content-type": "application/json",
            "accept": "application/json"
            },
            "body": JSON.stringify({
                ItemName: this.state.ItemName,
                UnitMeasurement: this.state.UnitMeasurement,
                UnitPrice: this.state.UnitPrice,
                Priority: this.state.Priority,
                Completed: this.state.Completed,
                PhotoFileName: this.state.PhotoFileName
            })
        })
        .then(response => response.json())
        .then(response => {
            console.log(response)
            Swal.fire(response.toString());
        })
        .catch(err => {
            console.log(err);
              Swal.fire({
             icon: 'error',
             title: 'Oops...',
              text: err.toString(),
            })  
             return;    
        });
                 
       this.setState={
            Name: '',
            UnitMeasurement:'',
            UnitPrice:'',
            Priority:'Low',
            Completed:false, 
            PhotoFileName: ''
        } 
        this.handleClick();                
    }
    
    onImageChange = (e) => {       
        if (e.target.files && e.target.files[0]) {
          let reader = new FileReader();
          reader.onload = (e) => {
            this.setState({image: e.target.result});        
          };
          reader.readAsDataURL(e.target.files[0]);
          var fileName = e.target.files[0].name;
          this.setState({PhotoFileName: fileName});           
        }
    }
    handleClick = () => {
        this.props.history.push("/");
    }

    render() {
        return (
            <div stye={{marginTop:20}}>
              <h3>Create New Item</h3> 
                <form onSubmit={this.onSubmit}>
                    <div clasname="form-group">      
                        <label>Item Name</label>
                        <input type="text" 
                         className="form-control"
                            value={this.state.ItemName}
                            onChange={(e) => this.setState({ ItemName: e.target.value })}
                            id="ItemName"/>
                    </div>
                    <div clasname="form-group"> 
                    
                        <label>Unit Measurement</label>
                        <input type="text" 
                         className="form-control"
                            value={this.state.UnitMeasurement}
                            onChange={(e) => this.setState({ UnitMeasurement: e.target.value })}
                            id="UnitMeasurement"/>
                    </div>
                    <div clasname="form-group">     
                        <label>Unit Price</label>
                        <input type="text" 
                         className="form-control"
                         value={this.state.UnitPrice}
                         onChange={(e) => this.setState({ UnitPrice: e.target.value })}
                         id="UnitPrice"/>
                    </div>                   
                    
                    <div className="form-check form-check-inline" 
                     onChange={(e) => this.setState({ Priority: e.target.value })}>
                     
                        <label className="form-check-input mr-3">Priority: </label>
                        <label className="form-check-input mr-2">
                        <input type="radio" 
                            value="Low" 
                            name="Priority"                                                 
                            />{" "}
                            Low
                        </label>
                        <label className="form-check-input mr-2">
                        <input type="radio" value="Medium" name="Priority"
                            />{" "}
                            Medium
                        </label>
                        <label className="form-check-input mr-2">
                        <input type="radio" value="High" name="Priority"
                            />{" "}
                            High
                        </label>
                    </div>   
                    <div clasname="form-group">                                        
                        <input type="file" 
                            onChange={this.onImageChange} 
                            className="filetype" 
                            id="group_image"/>   
                            <img id="target" alt=''  height="100px" 
                            width="100px" src={this.state.image}
                        /> 
                    </div>       
                    <div className="form-group">
                        <span className="mr-2">
                         <input type="submit" value="Save" className="btn btn-primary" />
                        </span>
                        <span  className="mr-2">
                        <button  className="btn btn-primary" onClick={this.handleClick}>Cancel</button>          
                        </span>
                    </div>               
                </form>
            </div> 
        )
    }
}
export default CreateMerchandise
