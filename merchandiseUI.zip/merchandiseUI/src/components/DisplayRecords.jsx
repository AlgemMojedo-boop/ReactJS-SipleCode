import React, { Component } from 'react';  
//import Swal from 'sweetalert2'
const PhotoUrl = "http://localhost:50976/Photos/";
class DisplayRecords extends Component {
    constructor() {
        super();
        this.state = {
          counter: null,
        };
      }

    render() {   
        alert(JSON.stringify(this.state));
        const PhotoFile = PhotoUrl +  this.props.counter.PhotoFileName ;     
        return (  
            <div>  
               
               <img src={PhotoFile} height="100" width="100" alt=""></img>       
                <span>{this.props.counter.ItemName} </span>  
               
                 <span>{this.currencyFormat(this.props.counter.UnitPrice)}/</span>
                 <span>{this.props.counter.UnitMeasurement}</span>  
            </div>       
        );
    }
    
    currencyFormat(num) {
        if (num === null) {
           num = 0.00; 
        }
        return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
     }

    

    formatCount(){
        if (this.props.counter === null) {
            this.props.counter = 0;
        }
        const {order} = this.props.counter;
        return order === 0 ? "Zero" : order;
    }
}
 
export default DisplayRecords;