import React, { Component } from 'react'

class Modal extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      name: '' };
    }
  render() {
    return (
      <div>
        oks
      </div>
    )
  }
}
export default Modal
