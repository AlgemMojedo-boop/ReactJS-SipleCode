export default class Merchandise {
   
  Id:number;
  Name: string;
  UnitMeasurement: string;
  Priority: string;
  PhotoFileName: string;
  UnitPrice: number;
  Completed: boolean;
  order: number;

  
    constructor(item: any) {
      this.Id = item.Id
      this.UnitMeasurement= item.UnitMeasurement;
      this.Name = item.Name;
      this.Priority = item.Priority;
      this.PhotoFileName = item.PhotoFileName;
      this.UnitPrice = item.UnitPrice;  
      this.Completed = item.Completed;
      this.order = item.order;   
    }
  }
  

 